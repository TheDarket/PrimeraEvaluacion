package com.example.evaluacion;

public class Publicacion {
    private String tipo;
    private String titulo;

    public Publicacion(String tipo, String titulo) {
        this.tipo = tipo;
        this.titulo = titulo;
    }

    public String getTipo() {
        return tipo;
    }

    public String getTitulo() {
        return titulo;
    }

    @Override
    public String toString() {
        return titulo;
    }
}
