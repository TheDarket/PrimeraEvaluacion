package com.example.evaluacion;

public interface Prestable {
    void prestar();
    void devolver();
    boolean estaPrestado();
}