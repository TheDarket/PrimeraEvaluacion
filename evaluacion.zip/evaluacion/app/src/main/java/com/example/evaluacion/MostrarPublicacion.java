package com.example.evaluacion;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MostrarPublicacion extends AppCompatActivity {

    private Spinner spinnerTipoPublicacion;
    private ListView listViewPublicaciones;
    private Button btnEliminarPublicacion;
    private Button btnPublicaciones;

    private List<Publicacion> publicaciones;
    private ArrayAdapter<Publicacion> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_publicacion);

        spinnerTipoPublicacion = findViewById(R.id.spinnerTipoPublicacion);
        listViewPublicaciones = findViewById(R.id.listViewPublicaciones);
        btnEliminarPublicacion = findViewById(R.id.btnEliminarPublicacion);

        publicaciones = new ArrayList<>();
        publicaciones.add(new Publicacion("Libro", "Libro 1"));
        publicaciones.add(new Publicacion("Revista", "Revista 1"));
        publicaciones.add(new Publicacion("Libro", "Libro 2"));
        publicaciones.add(new Publicacion("Revista", "Revista 2"));

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, publicaciones);
        listViewPublicaciones.setAdapter(adapter);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.tipos_publicacion, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTipoPublicacion.setAdapter(spinnerAdapter);

        spinnerTipoPublicacion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String tipoSeleccionado = parentView.getItemAtPosition(position).toString();
                filtrarPublicacionesPorTipo(tipoSeleccionado);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });

        listViewPublicaciones.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Publicacion publicacionSeleccionada = publicaciones.get(position);
                Toast.makeText(MostrarPublicacion.this,
                        "Publicación seleccionada: " + publicacionSeleccionada.getTitulo(),
                        Toast.LENGTH_SHORT).show();
            }
        });

        listViewPublicaciones.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                btnEliminarPublicacion.setVisibility(View.VISIBLE);
                btnEliminarPublicacion.setTag(position);
                return true;
            }
        });

        btnEliminarPublicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = (int) btnEliminarPublicacion.getTag();
                if (position >= 0 && position < publicaciones.size()) {
                    publicaciones.remove(position);
                    adapter.notifyDataSetChanged();
                    btnEliminarPublicacion.setVisibility(View.GONE);
                }
            }
        });

        btnPublicaciones.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }

    private void filtrarPublicacionesPorTipo(String tipo) {
        List<Publicacion> publicacionesFiltradas = new ArrayList<>();
        for (Publicacion publicacion : publicaciones) {
            if (publicacion.getTipo().equals(tipo)) {
                publicacionesFiltradas.add(publicacion);
            }
        }
        adapter.clear();
        adapter.addAll(publicacionesFiltradas);
        adapter.notifyDataSetChanged();
    }
}
