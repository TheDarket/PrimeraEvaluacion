package com.example.evaluacion;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MostrarLibrosActivity extends AppCompatActivity {

    private ListView listViewLibros;
    private ArrayAdapter<Libros> librosAdapter;
    private List<Libros> listaLibros;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_libros);

        listaLibros = new ArrayList<>();

        librosAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaLibros);

        listViewLibros = findViewById(R.id.listViewLibros);

        listViewLibros.setAdapter(librosAdapter);

        Libros libro1 = new Libros(1, "Libro 1", 2023);
        listaLibros.add(libro1);
        librosAdapter.notifyDataSetChanged();
    }
}
