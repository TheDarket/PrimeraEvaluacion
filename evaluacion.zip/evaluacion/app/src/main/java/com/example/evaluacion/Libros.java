package com.example.evaluacion;

import com.example.evaluacion.Prestable;

public class Libros implements Prestable {
    private int codigo;
    private String titulo;
    private int anio;
    private boolean prestado;
    private int vecesPrestado;
    public Libros(int codigo, String titulo, int anio) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.anio = anio;
        this.prestado = false;
        this.vecesPrestado = 0;
    }
    @Override
    public void prestar() {
        if (!prestado) {
            prestado = true;
            vecesPrestado++;
        }
    }

    @Override
    public void devolver() {
        if (prestado) {
            prestado = false;
        }
    }

    @Override
    public boolean estaPrestado() {
        return prestado;
    }

    public int getVecesPrestado() {
        return vecesPrestado;
    }

    public void setVecesPrestado(int vecesPrestado) {
        this.vecesPrestado = vecesPrestado;
    }
}

