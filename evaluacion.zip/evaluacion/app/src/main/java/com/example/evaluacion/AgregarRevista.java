package com.example.evaluacion;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class AgregarRevista extends AppCompatActivity {

    private Button btnLibrosRevista, btnRevistasRevista, btnAgregarRevista;
    private EditText etTituloRevista, etAnioRevista;
    private ListView listViewRevistas;
    private TextView tvBienvenidoRevista, tvNumeroRevistasRevista;

    private List<AgregarRevista> revistasList;
    private ArrayAdapter<AgregarRevista> revistasAdapter;
    private int numeroRevistas = 0;

    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_revista);

        btnRevistasRevista = findViewById(R.id.btnRevistasRevista);
        btnAgregarRevista = findViewById(R.id.btnAgregarRevista);
        etTituloRevista = findViewById(R.id.etTituloLibro);
        etAnioRevista = findViewById(R.id.btnRevistas);
        listViewRevistas = findViewById(R.id.listViewRevistas);
        tvBienvenidoRevista = findViewById(R.id.tvBienvenidoRevista);
        tvNumeroRevistasRevista = findViewById(R.id.btnRevistasRevista);

        revistasList = new ArrayList<>();
        revistasAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, revistasList);
        listViewRevistas.setAdapter(revistasAdapter);

        btnAgregarRevista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String titulo = etTituloRevista.getText().toString();
                String anio = etAnioRevista.getText().toString();

                if (titulo.isEmpty() || anio.isEmpty()) {
                    Toast.makeText(AgregarRevista.this, "Por favor, complete todos los campos.", Toast.LENGTH_SHORT).show();
                    return;
                }

                AgregarRevista nuevaRevista = new AgregarRevista ();
                revistasList.add(nuevaRevista);

                numeroRevistas++;

                tvNumeroRevistasRevista.setText("Número de Revistas: " + numeroRevistas);

                revistasAdapter.notifyDataSetChanged();

                etTituloRevista.setText("");
                etAnioRevista.setText("");
            }
        });

        btnLibrosRevista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(AgregarRevista.this, "Abriendo la sección de Libros.", Toast.LENGTH_SHORT).show();
            }
        });

        btnRevistasRevista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(AgregarRevista.this, "Ya estás en la sección de Revistas.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}